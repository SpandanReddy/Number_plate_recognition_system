import cv2
import numpy as np
import os
import DetectChars
import DetectPlates
import PossiblePlate
import pymysql as pysql



#established a connection to database

con=pysql.connect("localhost","spandan","spandy","spandan")
cur=con.cursor()

SCALAR_BLACK = (0.0, 0.0, 0.0)
SCALAR_WHITE = (255.0, 255.0, 255.0)
SCALAR_YELLOW = (0.0, 255.0, 255.0)
SCALAR_GREEN = (0.0, 255.0, 0.0)
SCALAR_RED = (0.0, 0.0, 255.0)

showSteps =True

def main():

    blnKNNTrainingSuccessful = DetectChars.loadKNNDataAndTrainKNN() 

    if blnKNNTrainingSuccessful == False:                           
        print("\nerror: KNN traning was not successful\n")  
        return                                                      

    imgOriginalScene  = cv2.imread("19.jpg")        

    if imgOriginalScene is None:                            
        print("\nerror: image not read from file \n\n")  
        os.system("pause")                              
        return                                  

    listOfPossiblePlates = DetectPlates.detectPlatesInScene(imgOriginalScene)           

    listOfPossiblePlates = DetectChars.detectCharsInPlates(listOfPossiblePlates)        

    cv2.imshow("imgOriginalScene", imgOriginalScene)    

    if len(listOfPossiblePlates) == 0:                  
        print("\nno license plates were detected\n")  
    else:                       
        listOfPossiblePlates.sort(key = lambda possiblePlate: len(possiblePlate.strChars), reverse = True)

        licPlate = listOfPossiblePlates[0]
        

        cv2.imshow("imgPlate", licPlate.imgPlate)   
        cv2.imshow("imgThresh", licPlate.imgThresh)

        if len(licPlate.strChars) == 0:                     
            print("\nno characters were detected\n\n")  
            return              
    

        drawRedRectangleAroundPlate(imgOriginalScene, licPlate)
        a=licPlate.strChars
        
        

        #wrote the select query----------------------------------
        
        cur.execute('select * from vehicle_details where reg_no=(%s)',[a])
        
        j=[]
        #displaying the details fetched from the table

        for i in cur:
            j.append(i)

        print('')
        print('------- VEHICLE DETAILS OF {}--------'.format(a))
        print('ID : {} '.format(j[0][0]))
        print('REGISTRATION NO : {} '.format(j[0][1]))
        print('OWNER NAME : {} '.format(j[0][2]))
        print('ADDRESS : {} '.format(j[0][3]))
        print('MAKERS CLASS : {} '.format(j[0][4]))
        print('VEHICLE CLASS : {} '.format(j[0][5]))
        print('MANUFACTURED DATE : {} '.format(j[0][6]))
        print('CHASSIS NUMBER : {} '.format(j[0][7]))
        print('DATE OF REGISTRATION : {} '.format(j[0][8]))
        print('REG VALID UPTO : {} '.format(j[0][9]))


        
        con.commit()
        con.close()

        print("\nlicense plate read from image = " + a + "\n")  
        print("----------------------------------------")

        writeLicensePlateCharsOnImage(imgOriginalScene, licPlate)       

        cv2.imshow("imgOriginalScene", imgOriginalScene)                

        cv2.imwrite("imgOriginalScene.png", imgOriginalScene)   

    

    cv2.waitKey(0)			

    return
def drawRedRectangleAroundPlate(imgOriginalScene, licPlate):

    p2fRectPoints = cv2.boxPoints(licPlate.rrLocationOfPlateInScene)

    cv2.line(imgOriginalScene, tuple(p2fRectPoints[0]), tuple(p2fRectPoints[1]), SCALAR_RED, 2) 
    cv2.line(imgOriginalScene, tuple(p2fRectPoints[1]), tuple(p2fRectPoints[2]), SCALAR_RED, 2)
    cv2.line(imgOriginalScene, tuple(p2fRectPoints[2]), tuple(p2fRectPoints[3]), SCALAR_RED, 2)
    cv2.line(imgOriginalScene, tuple(p2fRectPoints[3]), tuple(p2fRectPoints[0]), SCALAR_RED, 2)

def writeLicensePlateCharsOnImage(imgOriginalScene, licPlate):
    ptCenterOfTextAreaX = 0                         
    ptCenterOfTextAreaY = 0

    ptLowerLeftTextOriginX = 0                  
    ptLowerLeftTextOriginY = 0

    sceneHeight, sceneWidth, sceneNumChannels = imgOriginalScene.shape
    plateHeight, plateWidth, plateNumChannels = licPlate.imgPlate.shape

    intFontFace = cv2.FONT_HERSHEY_SIMPLEX                  
    fltFontScale = float(plateHeight) / 30.0                    
    intFontThickness = int(round(fltFontScale * 1.5))           

    textSize, baseline = cv2.getTextSize(licPlate.strChars, intFontFace, fltFontScale, intFontThickness)    

    ( (intPlateCenterX, intPlateCenterY), (intPlateWidth, intPlateHeight), fltCorrectionAngleInDeg ) = licPlate.rrLocationOfPlateInScene

    intPlateCenterX = int(intPlateCenterX)      
    intPlateCenterY = int(intPlateCenterY)

    ptCenterOfTextAreaX = int(intPlateCenterX)         

    if intPlateCenterY < (sceneHeight * 0.75):                                                  
        ptCenterOfTextAreaY = int(round(intPlateCenterY)) + int(round(plateHeight * 1.6))      
    else:                                                                                   
        ptCenterOfTextAreaY = int(round(intPlateCenterY)) - int(round(plateHeight * 1.6))      

    textSizeWidth, textSizeHeight = textSize            

    ptLowerLeftTextOriginX = int(ptCenterOfTextAreaX - (textSizeWidth / 2))     
    ptLowerLeftTextOriginY = int(ptCenterOfTextAreaY + (textSizeHeight / 2))          

    cv2.putText(imgOriginalScene, licPlate.strChars, (ptLowerLeftTextOriginX, ptLowerLeftTextOriginY), intFontFace, fltFontScale, SCALAR_YELLOW, intFontThickness)
    
if __name__ == "__main__":
    main()


















